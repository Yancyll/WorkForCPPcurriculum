#pragma once
#include <string>

namespace adas {

struct Pose {
    int x;
    int y;
    char heading;

    // 添加重载运算符用于测试比较
    bool operator==(const Pose& other) const {
        return x == other.x && y == other.y && heading == other.heading;
    }
};

class Executor {
public:
    virtual ~Executor() = default;

    // Caller should delete *executor when it is no longer needed.
    static Executor* NewExecutor(const Pose& pose) noexcept;

    virtual void Execute(const std::string& command) noexcept = 0;
    virtual Pose Query() const noexcept = 0;

    Executor() = default;
    Executor(const Executor&) = delete;
    Executor& operator=(const Executor&) = delete;
};

} // namespace adas
