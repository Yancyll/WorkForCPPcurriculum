#pragma once
#include "PoseHandler.hpp"
#include <functional>

namespace adas {

class MoveCommand final {
public:
    const std::function<void(PoseHandler&)> operate = [](PoseHandler& handler) noexcept {
        handler.Move();
    };
};

class TurnLeftCommand final {
public:
    const std::function<void(PoseHandler&)> operate = [](PoseHandler& handler) noexcept {
        handler.TurnLeft();
    };
};

class TurnRightCommand final {
public:
    const std::function<void(PoseHandler&)> operate = [](PoseHandler& handler) noexcept {
        handler.TurnRight();
    };
};

class FastCommand final {
public:
    const std::function<void(PoseHandler&)> operate = [](PoseHandler& handler) noexcept {
        handler.Fast();
    };
};

class ReverseCommand final {
public:
    const std::function<void(PoseHandler&)> operate = [](PoseHandler& handler) noexcept {
        handler.Reverse();
    };
};

} // namespace adas
