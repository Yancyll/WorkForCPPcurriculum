#pragma once
#include "Executor.hpp"

namespace adas {

class PoseHandler final {
public:
    explicit PoseHandler(const Pose& initialPose) noexcept;
    PoseHandler(const PoseHandler&) = delete;
    PoseHandler& operator=(const PoseHandler&) = delete;

    void Move() noexcept;
    void MoveForZ() noexcept;
    void MoveNoB() noexcept; // 新增：不受B影响的移动，只前进一步
    void TurnLeft() noexcept;
    void TurnLeftForZ() noexcept;
    void TurnRight() noexcept;
    void TurnRightForZ() noexcept;
    void Fast() noexcept;
    bool IsFast() const noexcept;

    void Reverse() noexcept; 
    bool IsReverse() const noexcept; 

    Pose Query() const noexcept;

private:
    Pose pose;
    bool fast;
    bool reverse; 
};

} // namespace adas
