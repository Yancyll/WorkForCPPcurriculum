#pragma once
#include "ActionGroup.hpp"
#include "PoseHandler.hpp"

namespace adas {

class TurnRoundCommand final {
public:
    ActionGroup operator()(PoseHandler& handler) const noexcept {
        ActionGroup actionGroup;

        // Z不受B影响，不检查IsReverse()
        if (handler.IsFast()) {
            // 加速模式下：先前进(1格) -> 左转 -> 再前进(1格) -> 左转
            actionGroup.PushAction(ActionType::FORWARD_1_STEP_NO_B_ACTION);
            actionGroup.PushAction(ActionType::TURNLEFT_ACTION);
            actionGroup.PushAction(ActionType::FORWARD_1_STEP_NO_B_ACTION);
            actionGroup.PushAction(ActionType::TURNLEFT_ACTION);
        } else {
            // 普通模式下Z：左转 -> 前进(1格) -> 左转
            actionGroup.PushAction(ActionType::TURNLEFT_ACTION);
            actionGroup.PushAction(ActionType::FORWARD_1_STEP_NO_B_ACTION);
            actionGroup.PushAction(ActionType::TURNLEFT_ACTION);
        }

        return actionGroup;
    }
};

} // namespace adas
