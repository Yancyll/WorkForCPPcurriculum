#include "ExecutorImpl.hpp"
#include "TurnRoundCommand.hpp"
#include <unordered_map>
#include <functional>

namespace adas {

Executor* Executor::NewExecutor(const Pose& pose) noexcept {
    return new (std::nothrow) ExecutorImpl(pose);
}

ExecutorImpl::ExecutorImpl(const Pose& initialPose) noexcept
    : poseHandler(initialPose) {}

void ExecutorImpl::Execute(const std::string& commands) noexcept {
    static const std::unordered_map<char, std::function<void(PoseHandler&)>> commandMap{
        {'M', MoveCommand().operate},
        {'L', TurnLeftCommand().operate},
        {'R', TurnRightCommand().operate},
        {'B', ReverseCommand().operate},
        {'F', FastCommand().operate},
    };

    TurnRoundCommand turnRoundCommand;

    for (const auto cmd : commands) {
        if (cmd == 'Z') {
            auto actionGroup = turnRoundCommand(poseHandler);
            actionGroup.DoOperate(poseHandler);
        } else if (auto it = commandMap.find(cmd); it != commandMap.end()) {
            it->second(poseHandler);
        }
    }
}


Pose ExecutorImpl::Query() const noexcept {
    return poseHandler.Query();
}

} // namespace adas
