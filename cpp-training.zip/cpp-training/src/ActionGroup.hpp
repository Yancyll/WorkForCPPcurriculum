#pragma once
#include "PoseHandler.hpp"
#include <list>

namespace adas {

enum class ActionType : uint16_t {
    FORWARD_1_STEP_ACTION = 0,
    BACKWARD_1_STEP_ACTION,
    TURNLEFT_ACTION,
    TURNRIGHT_ACTION,
    BE_FAST_ACTION,
    BE_REVERSE_ACTION,
    FORWARD_1_STEP_NO_B_ACTION // 新增此动作类型
};

class ActionGroup final {
public:
    ActionGroup() = default;
    explicit ActionGroup(const std::list<ActionType>& actions) noexcept;
    ~ActionGroup() = default;

    void PushAction(ActionType action) noexcept;
    void DoOperate(PoseHandler& poseHandler) const noexcept;

private:
    std::list<ActionType> actions;
};

} // namespace adas
