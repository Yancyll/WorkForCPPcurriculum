#include "PoseHandler.hpp"

namespace adas {

PoseHandler::PoseHandler(const Pose& initialPose) noexcept
    : pose(initialPose), fast(false), reverse(false) {}

void PoseHandler::Move() noexcept {
    int step = 1; 
    if (fast) {
        step = 2; // 加速模式两步
    }

    if (reverse) {
        step = -step; 
    }

    if (pose.heading == 'E') {
        pose.x += step;
    } else if (pose.heading == 'W') {
        pose.x -= step;
    } else if (pose.heading == 'N') {
        pose.y += step;
    } else if (pose.heading == 'S') {
        pose.y -= step;
    }
}

void PoseHandler::MoveForZ() noexcept {
    if (pose.heading == 'E') {
        pose.x += 1;
    } else if (pose.heading == 'W') {
        pose.x -= 1;
    } else if (pose.heading == 'N') {
        pose.y += 1;
    } else if (pose.heading == 'S') {
        pose.y -= 1;
    }
}

void PoseHandler::MoveNoB() noexcept {
    // 不管fast和reverse，始终只前进1格
    int step = 1;
    if (pose.heading == 'E') {
        pose.x += step;
    } else if (pose.heading == 'W') {
        pose.x -= step;
    } else if (pose.heading == 'N') {
        pose.y += step;
    } else if (pose.heading == 'S') {
        pose.y -= step;
    }
}

void PoseHandler::TurnLeft() noexcept {
    if(fast){
        if (pose.heading == 'E') {
            pose.x += 1;
        } else if (pose.heading == 'W') {
           pose.x -= 1;
        } else if (pose.heading == 'N') {
           pose.y += 1;
        } else if (pose.heading == 'S') {
           pose.y -= 1;
        }
    }
    pose.heading = (pose.heading == 'N') ? 'W' :
                   (pose.heading == 'W') ? 'S' :
                   (pose.heading == 'S') ? 'E' : 'N';
}

void PoseHandler::TurnLeftForZ() noexcept{
    pose.heading = (pose.heading == 'N') ? 'W' :
                   (pose.heading == 'W') ? 'S' :
                   (pose.heading == 'S') ? 'E' : 'N';
}

void PoseHandler::TurnRight() noexcept {
    if(fast){
        if (pose.heading == 'E') {
            pose.x += 1;
        } else if (pose.heading == 'W') {
           pose.x -= 1;
        } else if (pose.heading == 'N') {
           pose.y += 1;
        } else if (pose.heading == 'S') {
           pose.y -= 1;
        }
    }    
    pose.heading = (pose.heading == 'N') ? 'E' :
                   (pose.heading == 'E') ? 'S' :
                   (pose.heading == 'S') ? 'W' : 'N';
}

void PoseHandler::TurnRightForZ() noexcept{
    pose.heading = (pose.heading == 'N') ? 'E' :
                   (pose.heading == 'E') ? 'S' :
                   (pose.heading == 'S') ? 'W' : 'N';
}

void PoseHandler::Fast() noexcept {
    fast = !fast; 
}

bool PoseHandler::IsFast() const noexcept {
    return fast;
}

void PoseHandler::Reverse() noexcept {
    reverse = !reverse; 
}

bool PoseHandler::IsReverse() const noexcept {
    return reverse;
}

Pose PoseHandler::Query() const noexcept {
    return pose;
}

} // namespace adas
