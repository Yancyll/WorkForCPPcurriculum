#include "ActionGroup.hpp"

namespace adas {

ActionGroup::ActionGroup(const std::list<ActionType>& actions) noexcept
    : actions(actions) {}

void ActionGroup::PushAction(ActionType action) noexcept {
    actions.push_back(action);
}

void ActionGroup::DoOperate(PoseHandler& poseHandler) const noexcept {
    for (const auto& action : actions) {
        switch (action) {
            case ActionType::FORWARD_1_STEP_ACTION:
                poseHandler.MoveForZ(); 
                break;
            case ActionType::BACKWARD_1_STEP_ACTION:
                poseHandler.Move(); 
                break;
            case ActionType::TURNLEFT_ACTION:
                poseHandler.TurnLeftForZ();
                break;
            case ActionType::TURNRIGHT_ACTION:
                poseHandler.TurnRightForZ();
                break;
            case ActionType::BE_FAST_ACTION:
                poseHandler.Fast();
                break;
            case ActionType::BE_REVERSE_ACTION:
                poseHandler.Reverse();
                break;
            case ActionType::FORWARD_1_STEP_NO_B_ACTION:
                poseHandler.MoveNoB(); // 忽略B状态的特殊前进
                break;
            default:
                break;
        }
    }
}

} // namespace adas
