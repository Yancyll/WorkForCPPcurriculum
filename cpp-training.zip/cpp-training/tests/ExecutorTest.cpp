#include <gtest/gtest.h>
#include "Executor.hpp"

using namespace adas;

// 测试初始化位置和朝向
TEST(ExecutorTest, should_return_initial_pose_given_no_command_is_executed) {
    Pose initialPose = {2, 3, 'E'};
    Executor* executor = Executor::NewExecutor(initialPose);
    Pose pose = executor->Query();
    EXPECT_EQ(pose.x, 2);
    EXPECT_EQ(pose.y, 3);
    EXPECT_EQ(pose.heading, 'E');
    delete executor;
}

// 测试基础指令
TEST(ExecutorTest, should_return_y_plus_1_given_command_is_M_and_facing_is_N) {
    Pose initialPose = {0, 0, 'N'};
    Executor* executor = Executor::NewExecutor(initialPose);

    executor->Execute("M");
    Pose pose = executor->Query();
    EXPECT_EQ(pose.x, 0);
    EXPECT_EQ(pose.y, 1);
    EXPECT_EQ(pose.heading, 'N');

    delete executor;
}

TEST(ExecutorTest, should_return_heading_W_given_command_is_L_and_facing_is_N) {
    Pose initialPose = {0, 0, 'N'};
    Executor* executor = Executor::NewExecutor(initialPose);

    executor->Execute("L");
    Pose pose = executor->Query();
    EXPECT_EQ(pose.heading, 'W');

    delete executor;
}

TEST(ExecutorTest, should_return_heading_N_given_command_is_R_and_facing_is_W) {
    Pose initialPose = {0, 0, 'W'};
    Executor* executor = Executor::NewExecutor(initialPose);

    executor->Execute("R");
    Pose pose = executor->Query();
    EXPECT_EQ(pose.heading, 'N');

    delete executor;
}

//加速指令
TEST(ExecutorTest, should_return_y_plus_2_given_commands_and_F_and_M_and_facing_is_N) {
    Pose initialPose = {0, 0, 'N'};
    Executor* executor = Executor::NewExecutor(initialPose);

    executor->Execute("FM");
    Pose pose = executor->Query();
    EXPECT_EQ(pose.x, 0);
    EXPECT_EQ(pose.y, 2);

    delete executor;
}

TEST(ExecutorTest, should_return_y_plus_1_and_facing_W_given_commands_and_F_and_L_and_facing_is_N) {
    Pose initialPose = {0, 0, 'N'};
    Executor* executor = Executor::NewExecutor(initialPose);

    executor->Execute("FL");
    Pose pose = executor->Query();
    EXPECT_EQ(pose.x, 0);
    EXPECT_EQ(pose.y, 1);
    EXPECT_EQ(pose.heading, 'W');
    delete executor;
}

// 测试倒车指令
TEST(ExecutorTest, should_return_y_minus_1_given_command_is_M_and_facing_is_N_and_reverse_mode_is_enabled) {
    Pose initialPose = {0, 0, 'N'};
    Executor* executor = Executor::NewExecutor(initialPose);

    executor->Execute("B");
    executor->Execute("M");
    Pose pose = executor->Query();
    EXPECT_EQ(pose.x, 0);
    EXPECT_EQ(pose.y, -1);
    EXPECT_EQ(pose.heading, 'N');

    delete executor;
}

TEST(ExecutorTest, should_return_initial_pose_given_command_is_M_and_reverse_mode_is_toggled_twice) {
    Pose initialPose = {0, 0, 'N'};
    Executor* executor = Executor::NewExecutor(initialPose);

    executor->Execute("B");
    executor->Execute("M");
    executor->Execute("B");
    executor->Execute("M");
    Pose pose = executor->Query();
    EXPECT_EQ(pose.x, 0);
    EXPECT_EQ(pose.y, 0);

    delete executor;
}

TEST(ExecutorTest, should_return_y_minus_2_given_commands_are_B_and_F_and_M_and_facing_is_N) {
    Pose initialPose = {0, 0, 'N'};
    Executor* executor = Executor::NewExecutor(initialPose);

    executor->Execute("BFM");
    Pose pose = executor->Query();
    EXPECT_EQ(pose.x, 0);
    EXPECT_EQ(pose.y, -2);

    delete executor;
}

// 测试掉头指令
TEST(ExecutorTest, should_turn_left_forward_turn_left_given_Z_command) {
    Pose initialPose = {0, 0, 'E'};
    Executor* executor = Executor::NewExecutor(initialPose);

    executor->Execute("Z");
    Pose pose = executor->Query();
    EXPECT_EQ(pose.x, 0);
    EXPECT_EQ(pose.y, 1);
    EXPECT_EQ(pose.heading, 'W');

    delete executor;
}

TEST(ExecutorTest, should_ignore_Z_in_reverse_mode) {
    Pose initialPose = {0, 0, 'E'};
    Executor* executor = Executor::NewExecutor(initialPose);

    executor->Execute("BZ");
    Pose pose = executor->Query();
    EXPECT_EQ(pose.x, 0);
    EXPECT_EQ(pose.y, 1);
    EXPECT_EQ(pose.heading, 'W');

    delete executor;
}

TEST(ExecutorTest, should_execute_fast_Z_correctly) {
    Pose initialPose = {0, 0, 'E'};
    Executor* executor = Executor::NewExecutor(initialPose);

    executor->Execute("FZ");
    Pose pose = executor->Query();
    EXPECT_EQ(pose.x, 1);
    EXPECT_EQ(pose.y, 1);
    EXPECT_EQ(pose.heading, 'W');

    delete executor;
}

// 掉头与其他指令组合测试
TEST(ExecutorTest, should_execute_Z_and_other_commands_correctly) {
    Pose initialPose = {0, 0, 'N'};
    Executor* executor = Executor::NewExecutor(initialPose);

    executor->Execute("ZM");
    Pose pose = executor->Query();
    EXPECT_EQ(pose.x, -1); // 掉头后移动一步
    EXPECT_EQ(pose.y, -1);
    EXPECT_EQ(pose.heading, 'S');

    delete executor;
}

TEST(ExecutorTest, should_execute_F_and_Z_and_L_correctly) {
    Pose initialPose = {0, 0, 'N'};
    Executor* executor = Executor::NewExecutor(initialPose);

    executor->Execute("FZL");
    Pose pose = executor->Query();
    EXPECT_EQ(pose.x, -1); // 掉头后两步并左转
    EXPECT_EQ(pose.y, 0);
    EXPECT_EQ(pose.heading, 'E');

    delete executor;
}
