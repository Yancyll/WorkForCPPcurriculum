#!/bin/bash

bash script/build.sh
bash script/run.sh
